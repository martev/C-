﻿using System;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Моля въведете работни дни между 5 и 30");
            int N = int.Parse(Console.ReadLine());
            while (N < 5 || N > 30)//проверка дали въведените данни са коректни
            {
                Console.WriteLine("Моля въведете коректен брой работни дни между 5 и 30");
                 N = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Моля въведете средно възнаграждение между 10.00 и 2000.00");
            double M = double.Parse(Console.ReadLine());
            while (M < 10.00 || M > 2000.00)//проверка дали въведените данни са коректни
            {
                Console.WriteLine("Моля въведете коректно възнаграждение между 10.00 и 2000.00");
                M = double.Parse(Console.ReadLine());
            }            
            Console.WriteLine("Моля въведете курс на долара в диапазон от 0.99 до 1.99");
            double D = double.Parse(Console.ReadLine());
            while (D < 0.99 || D > 1.99)//проверка дали въведените данни са коректни
            {
                Console.WriteLine("Моля въведете коректен курс на долара в диапазон от 0.99 до 1.99");
                D = double.Parse(Console.ReadLine());
            }

            double L;//Тази променлива ще служи за събиране на изчисленията и извеждане на резултата
            L = ((N * M) * 12 + (N * M) * 2.5);//изчисляване на годишното възнаграждение плюс бонус
            L=L-(L*0.25);//изчисляване на данъка
            L = L / 365;//изчисляване на средното възнаграждение на ден от годината
            L = L * D;//обръщане на възнаграждението от долари в левове
            Console.WriteLine("Иван си изкарва {0:0.00}лв. средно на ден чисто възнаграждение ",L);
        }
    }
}
