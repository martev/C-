﻿using System;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, w, m;// x-тухли, w-работници, m-вместимост на количка
            Console.WriteLine("Моля въведете брой тухли между 1бр. и 1000бр.");
            x = int.Parse(Console.ReadLine());
            while (x < 1 || x > 1000)//проверка дали са въведени коректни данни, ако не са се изисква ново въвеждане
            { 
                
                Console.WriteLine("Моля въведете коректен брой тухли, трябва да са между 1бр. и 1000бр.");
                x = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Моля въведете броя на вашите работници, нека не са повече от 1000");
            w = int.Parse(Console.ReadLine());
            while (w < 1 || w > 1000)//проверка дали са въведени коректни данни, ако не са се изисква ново въвеждане 
            {
                if (w < 1)
                {
                    Console.WriteLine("Моля въведете коректен брой работници, едва ли са 0");
                    w = int.Parse(Console.ReadLine());
                }
                else if(w>1000)
                {
                    Console.WriteLine("Моля не използвайте повече от 1000 рабтоника");
                    w = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("Моля въведете вместимост на количката за пренасяне на тухли, нека е между 1бр. и 1000бр.");
            m = int.Parse(Console.ReadLine());
            while (m < 1 || m > 1000)//проверка дали са въведени коректни данни, ако не са се изисква ново въвеждане
            {
                if (m < 1)
                {
                    Console.WriteLine("Моля въведете коректна вместимост, едва ли е под 1бр.");
                    m = int.Parse(Console.ReadLine());
                }
                else if (m > 1000)
                {
                    Console.WriteLine("Моля не превишавайте 1000бр.");
                    m = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine($"Имаме {x}бр. тухли, които {w} работника трябва да прекарат с количка с вместимост {m}бр. тухли.");
            if (x%(m * w)==0)//проверка дали тухлите са кратни на работниците по вместимоста
            {
                Console.WriteLine($"нужни са {x / (m * w)} курса минимум");//ако са кратни извеждаме резултата
            }
            else
            {
                Console.WriteLine($"нужни са  {x / (m * w)+1} курса минимум");//ако не са кратни добавяме един курс защото иначе закръглява с 1 курс на долу
            }
                
        }
    }
}
