﻿namespace SDA_46191z_MyProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbValue = new System.Windows.Forms.TextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.rbFibonacci = new System.Windows.Forms.RadioButton();
            this.rbFactorial = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btClear = new System.Windows.Forms.Button();
            this.btPalindrom = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Въведете число или текст";
            // 
            // tbValue
            // 
            this.tbValue.Location = new System.Drawing.Point(13, 30);
            this.tbValue.Name = "tbValue";
            this.tbValue.Size = new System.Drawing.Size(193, 20);
            this.tbValue.TabIndex = 1;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 97);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(194, 96);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Резултат";
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(213, 29);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(135, 23);
            this.btnRun.TabIndex = 4;
            this.btnRun.Text = "Изчисли";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // rbFibonacci
            // 
            this.rbFibonacci.AutoSize = true;
            this.rbFibonacci.Location = new System.Drawing.Point(6, 19);
            this.rbFibonacci.Name = "rbFibonacci";
            this.rbFibonacci.Size = new System.Drawing.Size(77, 17);
            this.rbFibonacci.TabIndex = 5;
            this.rbFibonacci.Text = "Фибоначи";
            this.rbFibonacci.UseVisualStyleBackColor = true;
            // 
            // rbFactorial
            // 
            this.rbFactorial.AutoSize = true;
            this.rbFactorial.Location = new System.Drawing.Point(6, 42);
            this.rbFactorial.Name = "rbFactorial";
            this.rbFactorial.Size = new System.Drawing.Size(83, 17);
            this.rbFactorial.TabIndex = 6;
            this.rbFactorial.Text = "Факториал";
            this.rbFactorial.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbFibonacci);
            this.groupBox1.Controls.Add(this.rbFactorial);
            this.groupBox1.Location = new System.Drawing.Point(213, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(135, 65);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Изберете дейстеие";
            // 
            // btClear
            // 
            this.btClear.Location = new System.Drawing.Point(213, 59);
            this.btClear.Name = "btClear";
            this.btClear.Size = new System.Drawing.Size(132, 23);
            this.btClear.TabIndex = 9;
            this.btClear.Text = "Изчисти";
            this.btClear.UseVisualStyleBackColor = true;
            this.btClear.Click += new System.EventHandler(this.btClear_Click);
            // 
            // btPalindrom
            // 
            this.btPalindrom.Location = new System.Drawing.Point(213, 169);
            this.btPalindrom.Name = "btPalindrom";
            this.btPalindrom.Size = new System.Drawing.Size(131, 23);
            this.btPalindrom.TabIndex = 10;
            this.btPalindrom.Text = "Палиндром?";
            this.btPalindrom.UseVisualStyleBackColor = true;
            this.btPalindrom.Click += new System.EventHandler(this.btPalindrom_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(357, 205);
            this.Controls.Add(this.btPalindrom);
            this.Controls.Add(this.btClear);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.tbValue);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "SDA_46191z_MyProject";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbValue;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.RadioButton rbFibonacci;
        private System.Windows.Forms.RadioButton rbFactorial;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btClear;
        private System.Windows.Forms.Button btPalindrom;
    }
}

