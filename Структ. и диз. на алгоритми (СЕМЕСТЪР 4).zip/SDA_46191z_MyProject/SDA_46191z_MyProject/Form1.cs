﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;



namespace SDA_46191z_MyProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class CStack
        {
            private int p_index;
            private ArrayList list;
            public CStack()
            {
                list = new ArrayList();
                p_index = -1;
            }
            public int Count
            {
                get
                {
                    return list.Count;
                }
            }
            public void Push(object item)
            {
                list.Add(item);
                p_index++;
            }
            public object Pop()
            {
                object obj = list[p_index];
                list.RemoveAt(p_index);
                p_index--;
                return obj;
            }
            public void Clear()
            {
                list.Clear();
                p_index = -1;
            }
            public object Peek()
            {
                return list[p_index];
            }
        }
        public class MyMath
        {
            private List<int> nums = new List<int>();
            public MyMath()
            {

            }
            public string GetFib(int n)
            {
                Decimal n1 = 0, n2 = 1, n3 = 0;
                if (n <= 1)
                {
                    int a = 1;
                    return a.ToString();
                }
                else
                    for (int i = 1; i < n; ++i)
                    {
                        n3 = n1 + n2;
                        n1 = n2;
                        n2 = n3;
                    }
                return n3.ToString();
            }
            public string GetFact(int n)
            {
                Decimal fact = 1;
                for (int i = 1; i <= n; i++)
                {
                    fact = fact * i;
                }
                return fact.ToString();
            }
        }
        MyMath m = new MyMath();
        private void btnRun_Click(object sender, EventArgs e)
        {
            //richTextBox1.Text = null;
            if (rbFibonacci.Checked)
            {
                bool isNumeric;
                try
                {
                    int i = int.Parse(tbValue.Text);
                    isNumeric = true;
                    string s = tbValue.Text;
                    int n = int.Parse(s);
                    richTextBox1.Text = String.Format(
                        "{0}-то число на Фибоначи е:{1}\n",n,m.GetFib(n).ToString());
                }
                catch
                {
                    isNumeric = false;
                    MessageBox.Show("Моля използвайте само числа");

                }
            }
            else if (rbFactorial.Checked)
            {
                bool isNumeric;
                try
                {
                    int i = int.Parse(tbValue.Text);
                    isNumeric = true;
                    string s = tbValue.Text;
                    int n = int.Parse(s);
                    if (n > 27)
                    {
                        rbFactorial.Checked = false;
                        MessageBox.Show("Към момента програмата " +
                            "може да изчисли факториал до !27");
                    }
                    richTextBox1.Text = String.Format(
                        "{0}! = {1}\n", n, m.GetFact(n).ToString());
                }
                catch
                {
                    isNumeric = false;
                    MessageBox.Show("Моля използвайте само числа");
                    
                }
                
            }
        }

        private void btClear_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = null;
        }

        private void btPalindrom_Click(object sender, EventArgs e)
        {
            //richTextBox1.Text = null;
            CStack aList = new CStack();
            string ch;
            char chr;
            string w = "";
            string wh = tbValue.Text;

            for (int i = 0; i < wh.Length; i++)
            {
                chr = wh[i];
                if (chr != ' ') w += chr;
            }

            if (w.Length > 2)
            {
                bool p = true;
                for (int i = 0; i < w.Length; i++)
                    aList.Push(w.Substring(i, 1));
                int pos = 0;
                while (aList.Count > 0)
                {
                    ch = aList.Pop().ToString();
                    if (ch != w.Substring(pos, 1))
                    {
                        p = false;
                        break;
                    }
                    pos++;
                }
                if (p)
                {
                    richTextBox1.Text = String.Format("{0} е ПАЛИНДРОМ.\n", wh);
                }
                else
                {
                    richTextBox1.Text = String.Format("{0} не е ПАЛИНДРОМ.\n", wh);
                }
            }
            else
            {
                richTextBox1.Text = String.Format("Въведената дума е < 3 символа. \n");
            }
        }

        private void tbValue_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }
    }
}
