﻿using System;

namespace Task5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Моля въведете броя на числата, които искате да използвате");//Подкана за въвеждане на брой числа
            int n = int.Parse(Console.ReadLine());// брой на числат

            int number; //При всяко завъртане на цикъла, това ще е нашето число
            int counter = 1;
            double sumNumber = 0;//тук се събира крайния резултат и се изчислява нашето средно аритметично
            for (int i = 1; i <= n; i++)//тук създаваме необходимия цикъл
            { 

                Console.WriteLine("Моля въведете желаното от вас число"); //подкана да се въведе число
                number = int.Parse(Console.ReadLine());//въвеждане на числото
                Console.WriteLine("Вие въведохте числото {0}, то е {1} по ред ",number,counter);//показване на числото и кое е по ред
                counter++;//брояч на числата

                sumNumber = sumNumber + number;//събиране на числата

                if (i == n)
                {
                    sumNumber = sumNumber / n;//след последното събиране тук се изчислява средното аритметично
                    Console.WriteLine("нашето средно аритметично от избраните {0} числа е {1:0.00}",n,sumNumber);//извеждане на броя числа и тяхното средно аритметично
                }

            }
        }
    }
}
