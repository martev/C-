﻿using System;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 2;
            Console.WriteLine("Моля въведете степента на която искате да повдигнем числото 2");
            int n =int.Parse(Console.ReadLine());
            Console.WriteLine("Повдигаме числото {0} на степен {1}",sum,n);
            int sumMax = sum;//променлива в която събираме нашето крайно число
            for (int i = 0; i <= n; i++)
            {
                if (i == 0)
                {
                    Console.WriteLine("{0}^{1} = {2}",sum,i,sumMax/sum);//понеже знаме че всяко число на степен 0 е равно на 1
                }
                else if (i == 1)
                {
                    Console.WriteLine("{0}^{1} = {2}",sum,i,sumMax *1);//понеже знаем че всяко число на степен 1 е равно на себе си 
                }
                else
                {
                    sumMax = sumMax * sum;//правиме необходимите умножения за да достигнем степента която търсим
                    Console.WriteLine("{0}^{1} = {2}", sum, i, sumMax);
                }

            }
        }
    }

}
