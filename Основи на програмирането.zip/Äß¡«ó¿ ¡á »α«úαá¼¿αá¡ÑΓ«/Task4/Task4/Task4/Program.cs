﻿using System;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Моля въведете число за Степен");//подканваме потребителя да въведе степен

            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Повдигаме 2 на степен {0}",n);

            int number = 2;//задаване на числото което ще повдигаме на степен, при желание може да се направи да се
                           // въвежда от потребителя  
            int numberMax = number;//в numbMax ще правим умноженията без да губим оригиналното число

            for (int i = 0; i <= n; i++)//цикъл за повдигане на степента която желаем
            {
                if (i == 0)//проверка ак остепента е 0
                {
                    Console.WriteLine("{0}^{1} = {2}", number, i, number / number);//всяко число на степен 0 е равно на 1

                }else if (i == 1)// проверка степента дали е 1
                {
                   numberMax=numberMax*1;//всяко число на степен 1 е равно на себеси 
                }
                else if (i % 2 == 0)//проверка дали степента е кратна на 2
                {
                    numberMax = numberMax * number;//правим необходимите умножения и събираме числото в нумб макс без да губим оригиналното
                    Console.WriteLine("{0}^{1} = {2} ",number,i,numberMax);//принтиране на всички числа на степен кратна на 2
                }
                else
                {
                    numberMax = numberMax * number;//всички останали получени числа чиито резултат не ни интересува
                }
            }
        }
    }
}
