﻿namespace TASK
{
    public class Student
    {
        private string name;//Име на студента
        int semester;//номер семестър
        string discipline;//дисциплина
        int lectures;//часове лекции
        int practice;//часове практика
        string teacher;//преподавател
        double evaluation;//оценка

        public Student(string name)
        {
            this.name = name;
        }

        public Student(int sem, string disc, int lec, int pra, string teach, double eval)
        {
            this.semester =sem ;
            this.discipline = disc;
            this.lectures = lec;
            this.practice = pra;
            this.teacher = teach;
            this.evaluation = eval;

        } 

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public int Semester
        {
            get { return this.semester; }
            set { this.semester = value; }
        }
        public string Discipline
        {
            get { return this.discipline; }
            set { this.discipline = value; }
        }

        public int Lectures
        {
            get { return this.lectures; }
            set { this.lectures = value; }
        }
        public int Practice
        {
            get { return this.practice; }
            set { this.practice = value; }
        }

        public string Teacher
        {
            get { return this.teacher; }
            set { this.teacher = value; }
        }
        public double Evaluation
        {
            get { return this.evaluation; }
            set { this.evaluation = value; }
        }
        double avgOcenka=0;
        public double avgEvaluation(double ocenka,int del)
        {
           avgOcenka = ocenka / del;
            return avgOcenka;
        }

        public void printAvgEvaluation()
        {
            System.Console.WriteLine("Общ среден успех:  {0:0.00}", avgOcenka);
        }
    }
}
