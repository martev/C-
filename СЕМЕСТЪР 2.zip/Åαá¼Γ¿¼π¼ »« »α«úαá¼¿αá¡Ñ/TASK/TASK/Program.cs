﻿using System;
using System.Collections.Generic;

namespace TASK
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Веведете информация за студент. Празно име за прекъсване.\n");
            Console.WriteLine("Формат за данни по дисциплина: " +
                              "{семестър №}, {дисциплина}, {лекции}, {упражнения}, {преподавател}, {оценка}).");
            Console.WriteLine("Възможно е въвеждане на множество записи за дисциплина чрез разделител ';'.\n");

            Console.Write("Студент: ");
            string a = Console.ReadLine();
            Student student1 = new Student(a);
            int b = 0;//номер семестър
            string c;//дисциплин
            int d = 0;//часове лекции
            int e = 0;//часове практик
            string f;//преподавател
            List<string> discpList = new List<string>();
            int g = 0;//оценка
            string[] split; 
            string info = Console.ReadLine();
            split = info.Split(';');
            string[] discpFields;
            Student[] studentList = new Student[split.Length]; 
            double sredOcenka = 0; 
            for (int i = 0; i < split.Length; i++)
            {
                discpList.Add(split[i]);
                discpFields = discpList[i].Split(',');

                b = Convert.ToInt32(discpFields[0]);
                if (b < 1 || b > 8)
                {
                    Console.WriteLine("Грешно въведени данни, моля стартирайте програмата отново и внимавайте повече ! Семестрите са между 1 и 8(включително)");
                    break;
                }
                c = discpFields[1];
                d = Convert.ToInt32(discpFields[2]);
                e = Convert.ToInt32(discpFields[3]);
                f = discpFields[4];
                g = Convert.ToInt32(discpFields[5]);
                if (g < 2 || g > 6)
                {
                    Console.WriteLine("Грешно въведени данни, моля стартирайте програмата отново и внимавайте повече. Оценките са между 2 и 6(включително)");
                    break;
                }
                studentList[i] = new Student(b, c, d, e, f, g); 
                sredOcenka = sredOcenka + studentList[i].Evaluation;
            }
            int z = split.Length; 
            int allHours = 0;
            double ocenchica = 0;
            int x = 0;
            int broqch = 0;  

            Console.WriteLine("Студент {0}",student1.Name);
            Console.WriteLine("Общо изучавани дисциплини: {0}", split.Length);
            Console.WriteLine("Среден успех по семестри и общ хорариум:");
            for (int i = 0; i <= z;)
            {
                x++;
                allHours = 0;
                ocenchica = 0;
                broqch = 0;
                while (studentList[i].Semester == x)
                {
                    allHours = allHours + studentList[i].Lectures + studentList[i].Practice;
                    ocenchica = ocenchica + studentList[i].Evaluation;
                    broqch++;
                    i++;
                    if (i == z)
                    {
                        break;
                    } 
                }
                ocenchica = ocenchica / broqch;
                Console.WriteLine(x + "." + "Семестър {0}, {1}:{2:0.00}", x, allHours, ocenchica);
                if (i == z)
                {
                    break;
                }


            }
            student1.avgEvaluation(sredOcenka, split.Length);
            student1.printAvgEvaluation();
        }
    }
}


