﻿namespace TASK1
{
     class Menu
    {
        private int clientAge;
        private double first;
        private double second;
        private double third;
        private double discountTwo;
        private double discountOne;

        public Menu(int age, double a, double b, double c, double d, double e)
        {
            this.first = a;
            this.second = b;
            this.third = c;
            this.discountOne = d;
            this.discountTwo = e;

        }
        public int ClientAge
        {
            get { return this.clientAge; }
            set { this.clientAge = value; }
        }

        public double First
        {
            get { return this.first; }
            set { this.first = value; }
        }
        public double Second
        {
            get { return this.second; }
            set { this.second = value; }
        }
        public double Third
        {
            get { return this.third; }
            set { this.third = value; }
        }
        public double DiscountOne
        {
            get { return this.discountOne; }
            set { this.discountOne = value; }
        }
        public double DiscountTwo
        {
            get { return this.discountTwo; }
            set { this.discountTwo = value; }
        }

        public void MakePriceKids(int age, double a,double b, double c, double disc )
        {
            first = first - (first * (discountOne / 100));
            second = second - (second * (discountOne / 100));
            third = third - (third * (discountOne / 100));
            System.Console.WriteLine("Цената за първо ястие за клиент на възраст {0}год. ще бъде {1}лв., цената за второ ще бъде {2}лв. и за трето  {3}лв.",age, first, second, third);

        }
        public void MakePriceOlder(int age, double a, double b, double c, double disc)
        {
            first = first - (first * (discountTwo / 100));
            second = second - (second * (discountTwo / 100));
            third = third - (third * (discountTwo / 100));
            System.Console.WriteLine("Цената за първо ястие за клиент на възраст {0}год. ще бъде {1}лв., цената за второ ще бъде {2}лв. и за трето  {3}лв.", age, first, second, third);
        }
        public void MakePriceAverage(int age)
        {
            System.Console.WriteLine("Цената за първо ястие за клиент на възраст {0}год. ще бъде {1}лв., цената за второ ще бъде {2}лв. и за трето  {3}лв.", age, first, second, third);
        }
    }
}
