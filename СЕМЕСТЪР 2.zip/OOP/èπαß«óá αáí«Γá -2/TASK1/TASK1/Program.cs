﻿using System;


namespace TASK1
{
    class Program
    {
        static void Main(string[] args)
        { 
            Console.Write("Имате ли клиент");
            Console.WriteLine("(моля отговорете с Да или Не)");
            string ask =Console.ReadLine();
            while (ask.ToLower() != "да" && ask.ToLower() != "не" && ask.ToLower() != "no" && ask.ToLower() != "yes")
            {
                Console.WriteLine("Моля използвайте 'Да' или 'не'");
                ask = Console.ReadLine();
            }
            while (ask.ToLower() == "да" ^ ask.ToLower() == "yes")
            {
                Console.Write("Моля въведете годините на клиента: ");
                int age = int.Parse(Console.ReadLine());
                Console.Write("Моля въведете цена за първо ястие от менюто: ");
                double a = double.Parse(Console.ReadLine());
                Console.Write("Моля въведете цена за второто ястие от менюто: ");
                double b = double.Parse(Console.ReadLine());
                Console.Write("Моля въведете цена за третото ястие от менюто: ");
                double c = double.Parse(Console.ReadLine());
                Console.Write("Моля въведете полагаемата отстъпка за под 12год. ученици: ");
                double d = double.Parse(Console.ReadLine());
                Console.Write("Моля въведете полагаемата отстъпка за пенсионери над 70год.: ");
                double e = double.Parse(Console.ReadLine());
                Menu menu = new Menu(age, a, b, c, d, e);
                if (age < 12)
                {
                    menu.MakePriceKids(age, a, b, c, d);
                }
                else if (age > 70)
                {
                    menu.MakePriceOlder(age, a, b, c, e);
                }
                else
                {
                    menu.MakePriceAverage(age);
                }
                Console.WriteLine("Имате ли друг клиент");
                ask = Console.ReadLine();
                if (ask.ToLower() != "yes" && ask.ToLower() != "да")
                {
                    Console.WriteLine("Няма повече клиенти");
                    break;

                }
            } 
        }
    }
}
