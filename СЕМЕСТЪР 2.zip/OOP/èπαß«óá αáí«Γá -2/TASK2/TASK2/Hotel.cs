﻿namespace TASK2
{
    class Hotel
    {
        private double finalPrice; 

        public double Burgas(int nights)
        {
            double price = 30;
            double discount = 6;

            if (nights <= 3)
            {
                finalPrice = price * nights;
                return finalPrice;

            }
            else
            {
                finalPrice = price * nights - ((price * nights) * (discount / 100));
                return finalPrice;
            }
        }
        public double Sozopol(int nights)
        {
            double price = 31;
            double discount = 5;

            if (nights <= 3)
            {
                finalPrice = price * nights;
                return finalPrice;

            }
            else
            {
                finalPrice = price * nights - ((price * nights) * (discount / 100));
                return finalPrice;
            }
        }
        public double zlatniPqsuci(int nights)
        {
            double price = 32;
            double discount = 5;

            if (nights <= 3)
            {
                finalPrice = price * nights;
                return finalPrice;

            }
            else
            {
                finalPrice = price * nights - ((price * nights) * (discount / 100));
                return finalPrice;
            }
        }
        public void showPrice()
        {
            System.Console.WriteLine("Стойността на вашата почивка ще бъде {0}лв.", finalPrice);
        }
    }
}
