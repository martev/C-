﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TASK2
{
    class City
    {
        private string name;
        private int nights;

        public City(string name, int nights)
        {
            this.name = name;
            this.nights = nights;
            
        }
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        } 
        public int Nights
        {
            get { return this.nights; }
            set { this.nights = value; }
        }
    }
}
