﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TASK2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Моля въведете корорта в които искате да изкарате лятото");
            string a = Console.ReadLine();
            Console.WriteLine("Моля въведете брой нощувки");
            int b = int.Parse(Console.ReadLine());
            City grad = new City(a,b); 
            Hotel seaSpark = new Hotel();
            if (grad.Name.ToLower() == "бургас" ^ grad.Name.ToLower() == "burgas")
            {
                seaSpark.Burgas(grad.Nights);
                seaSpark.showPrice();
            }
            else if (grad.Name.ToLower() == "созопол" ^ grad.Name.ToLower() == "sozopol")
            {
                seaSpark.Sozopol(grad.Nights);
                seaSpark.showPrice();
            }
            else if (grad.Name.ToLower() == "златни пясъци" ^ grad.Name.ToLower() == "zlatni pqsaci" ^
                grad.Name.ToLower() == "зл. пясъци" ^ grad.Name.ToLower() == "zl. pqsaci")
            {
                seaSpark.zlatniPqsuci(grad.Nights);
                seaSpark.showPrice();
            }
            else
            {
                Console.WriteLine("Верига хотели 'Морска Искра' няма хотел в посоченият от вас град");
            }
        }
    }
}
