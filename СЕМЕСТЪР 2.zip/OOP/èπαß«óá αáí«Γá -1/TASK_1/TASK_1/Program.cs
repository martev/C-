﻿using System;
//using Student;

namespace TASK_1
{
    class Student

    {
        private int fac;//fakulteten nomer
        private string fName;//purvo ime
        private string sName;//vtoro ime
        private string disc;//disciplina
        private int n;//tekushti ocenki
        double ball;

        public Student(string name, string sname, int fac, string disc, int n)
        {
            this.fac = fac;
            this.fName = name;
            this.sName = sname;
            this.disc = disc;
            this.n = n;
        }

        public int Fac
        {
            get { return this.fac; }
            set { this.fac = value; }
        }
        public string Name
        {
            get { return this.fName; }
            set { this.fName = value; }
        }
        public string Sname
        {
            get { return this.sName; }
            set { this.sName = value; }
        }
        public string Disc
        {
            get { return this.disc; }
            set { this.disc = value; }
        }
        public int N
        {
            get { return this.n; }
            set { this.n = value; }
        }
        public void Pechat()
        {
            Console.WriteLine("Име на студента: " + fName + " " + sName + " Факултетен номер: " + fac + " Изучава Дисциплина: " + disc);
        } 
        public double Sredna(int n)
        {
          
            int[] ocenka = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write("моля въведете оценка номер {0}: ", i + 1);
                int b = int.Parse(Console.ReadLine());
             
              while (b < 2 ^ b > 6)
              {
                  Console.Write("оценката няма как да е в диапазон различен от 2 до 6: ");
                  b = int.Parse(Console.ReadLine());
              }
                ball = ball + b;
            }

            ball = ball / n;
            return ball;
        }
        
        public void PrintBall()
        {
            Console.WriteLine($"Средната аритметична оценка по { disc} от наличните {N} оцентки е {ball:0.00}");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Моля въведете първото име на студента: ");
            string a = Console.ReadLine();//purvo ime na studenta
            Console.Write("Моля въведете второто име на студента: ");
            string b = Console.ReadLine();//vtoro ime na studenta
            Console.Write("Моля въведете факултетния номер на студента: ");
            int c = int.Parse(Console.ReadLine());//fakulteten nomet
            while (c < 10000 ^ c > 99999)
            {
                Console.Write("Факултетния номер трябва да е 5-цифрен, моля въведете коректен номер: ");
                c = int.Parse(Console.ReadLine());
            }
            Console.Write("Моля въведете учебната дисциплина на студента: ");
            string d = Console.ReadLine();//disciplina
            Console.Write("Моля въведете броя оценки: ");
            int n = int.Parse(Console.ReadLine());
            Student student1 = new Student(a, b, c, d, n);
            student1.Sredna(n);
            student1.Pechat();
            student1.PrintBall();
        }
    }
}
