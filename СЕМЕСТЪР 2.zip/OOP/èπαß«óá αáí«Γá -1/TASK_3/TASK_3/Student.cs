﻿using System;

namespace TASK_3
{
    internal class Student
    {
        private string fName;
        private string lName;
        private int fac;
        private string discipline;
        private int age;

        public Student(string fName, string lName, int fac, string discipline, int age)
        {
            this.fName = fName;
            this.lName = lName;
            this.fac = fac;           
            this.discipline = discipline;
            this.age = age;
        
        }
        public string FName
        {
            get { return this.fName; }
            set { this.fName = value; }
        }
        public string LName
        {
            get { return this.lName; }
            set { this.lName = value; }
        }
        public int Fac
        {
            get { return this.fac; }
            set { this.fac = value; }
        }
        public string Discipline
        {
            get { return this.discipline; }
            set { this.discipline = value; }
        }
        public int Age
        {
            get { return this.age; }
            set { this.age = value; }
        }
        public void WayOfLearning(int age)
        {
            if (age <= 25)
            {
                Console.WriteLine(fName + " " + lName + " с факултетен номер: " + fac + " на {0}г.",age);
            }
        }
    }
}
