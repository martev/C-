﻿using System;

namespace TASK_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string a;//Първо име
            string b;//второ име
            int c;//факултетен номер
            string d;//дисциплина
            int e;//възраст
            Console.Write("Моля въведете броя на студентите които искате да се създадат: ");
            int N = int.Parse(Console.ReadLine());
            Student[] klas = new Student[N];
            for (int i = 0; i < N; i++)
            {
                Console.Write("Моля въведете първото име на студент {0}: ", (i + 1));
                a = Console.ReadLine();
                Console.Write("Моля въведете второто име на студента {0}: ", (i + 1));
                b = Console.ReadLine();
                Console.Write("Моля въведете факултетния номер на студента {0}: ", (i + 1));
                c = int.Parse(Console.ReadLine());
                while (c < 10000 ^ c > 99999)
                {
                    Console.Write("Моля въведете коректен номер факултетен номер, трябва да е от 5 цифри: ");
                    c = int.Parse(Console.ReadLine());
                }
                Console.Write("Моля въведете дисциплината която изучава студента {0}: ", (i + 1));
                d = Console.ReadLine();
                Console.Write("Моля въведете годините на студента {0}: ", (i + 1));
                e = int.Parse(Console.ReadLine());
                while (e < 18)
                {
                    Console.Write("Студента не може да е под 18г. Моля въведете коректни години: ");
                    e = int.Parse(Console.ReadLine());
                }
                klas[i] = new Student(a, b, c, d, e);
            }
            Console.WriteLine("Студенти редовно форма на обучение: "); 
            foreach (Student student in klas)
            {
                student.WayOfLearning(student.Age);
            }
        }
    }
}
