﻿using System;

namespace TASK_2
{
     class Product
    {
        private string name;
        private string unit;
        private double wPrice;
        private double quantity;
        private double discount = 0.15;
        private double cEdro;
        private double cDrebno;

        public Product(string name, string unit, double price, double quantity)
        {
            this.name = name;
            this.unit = unit;
            this.wPrice = price;
            this.quantity = quantity;


        }
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }
        public string Unit
        {
            get { return this.unit; }
            set { this.unit = value; }
        }
        public double Price
        {
            get { return this.wPrice; }
            set { this.wPrice = value; }
        }
        public double Quantity
        {
            get { return this.quantity; }
            set { this.quantity = value; }
        }

        public double cenaEdro(double price)
        {
            cEdro = wPrice - (wPrice * discount);
            return cEdro;

        }
        public double cenaDrebno(double price)
        {
            cDrebno = (wPrice*1.2)*1.2;
            return cDrebno;
        }
        public void edCena()//цена за 1бр (1кг) 
        {
            Console.WriteLine("Цена на едро за 1{0} {1} е = {2:0.00}лв, цена на едро с отстъпка е = {3:0.00}лв, цената на дребно е = {4:0.00}лв", unit,name, wPrice, cEdro, cDrebno);
        }
        public void krCena()//крайна цена спрямо количеството (тежеста)
        {
            Console.WriteLine("Цена на едро за {0:0.00}{1} {2} е = {3:0.00}лв, цена на едро с отстъпка е = {4:0.00}лв, цената на дребно е = {5:0.00}лв",quantity, unit,name, wPrice*quantity, cEdro*quantity, cDrebno*quantity);
        } 
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Моля въведете име на продукт");
            string a = Console.ReadLine();
            Console.WriteLine("Моля въведете мерната единица за вашия продукт, използвайте 'кг' или 'бр'"); 
            string b = Console.ReadLine();
            while (b.ToLower() != "кг" && b.ToLower() != "бр")
            {
                Console.WriteLine("Грешна мерна единица, използвайте 'кг' или 'бр'");
                b = Console.ReadLine();
            }
                //Console.WriteLine("Моля въведете цена");
            Random rnd = new Random();

            double price = rnd.NextDouble() * (20.00 - 2.00) + 2.00;
            //Console.WriteLine("Моля въведете количество на продукта");
            double quantity = rnd.NextDouble() * (20.00 - 2.00) + 2.00;
            Product kafe = new Product(a, b, price, quantity);
            kafe.cenaDrebno(price);
            kafe.cenaEdro(price);
            kafe.edCena();
            kafe.krCena();
        }
    }
}
