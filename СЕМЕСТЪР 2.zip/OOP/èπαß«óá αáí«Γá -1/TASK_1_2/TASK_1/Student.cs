﻿using System;

namespace TASK_1
{
    class Student

    {
        private int fac;//fakulteten nomer
        private string fName;//purvo ime
        private string sName;//vtoro ime
        private string disc;//disciplina
        private int n;//tekushti ocenki
        private int[] ocenka = new int[500];//za sredna ocenka
        private double ball;

        public Student()
        {

        }

        public Student(string name, string sname, int fac, string disc, int n)
        {
            this.fac = fac;
            this.fName = name;
            this.sName = sname;
            this.disc = disc;
            this.n = n;

        }

        public int Fac
        {
            get { return this.fac; }
            set { this.fac = value; }
        }
        public string Name
        {
            get { return this.fName; }
            set { this.fName = value; }
        }
        public string Sname
        {
            get { return this.sName; }
            set { this.sName = value; }
        }
        public string Disc
        {
            get { return this.disc; }
            set { this.disc = value; }
        }
        public int N
        {
            get { return this.n; }
            set { this.n = value; }
        }
        public void Pechat()
        {
            Console.WriteLine("Име на студента " + fName + " " + sName + " Факултетен номер " + fac + " Изучава Дисциплина " + disc);
        }
        public double Sredna(int n)
        {
           
            int[] ocenka = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write("моля въведете оценка номер {0} ", (i + 1) + ": ");
                int b = int.Parse(Console.ReadLine());
                while (b < 2 ^ b > 6)
                {
                    Console.WriteLine("оценката няма как да е р диапазон различен от 2 до 6");
                    Console.Write("Моля въведете коректна оценка: ");
                    b = int.Parse(Console.ReadLine());
                }
                ball = ball + b;
            }
            ball = ball / n;
            return ball;
        }
        public void PrintBall(int n)
        {
            Console.WriteLine("Средната аритметична оценка по {0} от наличните {1} оцентки е {2:0.0}", disc, n, ball);
        }
    }
}
