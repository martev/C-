﻿using System;

namespace TASK_1
{

    class Program
    {
        static void Main(string[] args)
        { 
            Console.Write("Моля въведете броя студенти: ");
            int broi = int.Parse(Console.ReadLine());
            string a = null;
            string b = null;
            int c = 0;
            string d = null;
            int n = 0;
            Student[] klas = new Student[broi];
            for (int i = 0; i < broi; i++)
            {
                Console.Write("Моля въведете първото име на студента №{0}: ", i + 1);
                a = Console.ReadLine();//purvo ime na studenta
                Console.Write("Моля въведете второто име на студента №{0}: ", i + 1);
                b = Console.ReadLine();//vtoro ime na studenta
                Console.Write("Моля въведете факултетния номер на студента №: ");
                c = int.Parse(Console.ReadLine());//fakulteten nomet
                while (c < 10000 ^ c > 99999)
                {
                    Console.WriteLine("Факултетния номер трябва да е 5-цифрен, моля въведете коректен номер");
                    c = int.Parse(Console.ReadLine());
                }

                Console.Write("Моля въведете учебната дисциплина на студента №{0}: ", i + 1);
                d = Console.ReadLine();//disciplina
                Console.Write("Моля въведете броя оценки на студент №{0}: ", i + 1);
                n = int.Parse(Console.ReadLine());

                klas[i] = new Student(a, b, c, d, n);
                klas[i].Sredna(n); 
            }
            for (int i = 0; i < broi; i++)
            {
                Console.Write("Моля въведете номера на студента на който искате да видите средния успех");
                int x = int.Parse(Console.ReadLine());
                klas[x - 1].Pechat();
                klas[x - 1].PrintBall(klas[x - 1].N);

                Console.WriteLine("Ако сте готови напишете 'край', ако искате да проверите друг студент напишете 'Следващ'");
                string w = Console.ReadLine();
                while (w.ToLower() != "следващ" && w.ToLower() != "край")
                {
                    Console.WriteLine("моля използвайте 'край' или 'следващ'");
                    w = Console.ReadLine();
                }
                if (w.ToLower() == "край")
                {
                    break;
                }
                else if (w.ToLower() == "следващ")
                {
                    i--;
                    continue;
                }
            } 
        }
    }
}
