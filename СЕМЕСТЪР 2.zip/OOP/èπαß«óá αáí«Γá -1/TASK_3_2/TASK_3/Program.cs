﻿using System;

namespace TASK_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = null;
            string[] f = { "Иван", "Киро", "Пламен", "Мартин", "Павел", "Валентин", "Петър", "Георги", "Димитър", "Евгени" };//Първо име
            string b = null;
            string[] k = { "Иванов", "Василев", "Евтимов", "Петров", "Китов", "Панталеев", "Георгиев", "Кестенов", "Кушков", "Сиромахов" };//второ име
            Random rnd = new Random();
            int c;//факултетен номер
            string d = "ИКН";//дисциплина
            int e;//възраст
            Console.WriteLine("Моля въведете броя на студентите които искате да се създадат");
            int N = int.Parse(Console.ReadLine());
            Student[] klas = new Student[N];
            for (int i = 0; i < N; i++)
            {
                int j = rnd.Next(0, 10);
                a = f[j];
                j = rnd.Next(0, 10);
                b = k[j];
                c = rnd.Next(10000, 99999);
                e = rnd.Next(18, 40);
                klas[i] = new Student(a, b, c, d, e);
            }
            Console.WriteLine("Студенти редовна форма на обучение:");
            foreach (Student student in klas)
            {
                student.WayOfLearning(student.Age);
            }
        }
    }
}
