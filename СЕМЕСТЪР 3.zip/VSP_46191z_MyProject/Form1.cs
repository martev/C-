﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace VSP_46191z_MyProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.enCrypt.Enabled = false;
            this.deCrypt.Enabled = false;
            this.save.Enabled = false;
            this.load.Enabled = false;
            this.cryptoKey.Enabled = false;

        }
       
        private void enCrypt_Click(object sender, EventArgs e)
        {
            secretText.Text = "";

            foreach (char c in originText.Text)
            {
                char crypted = (char)(c + cryptoKey.Value);
                secretText.Text += crypted.ToString();
            }
            MessageBox.Show("Вашето криптирано съобщение е: " + secretText.Text);
            
        }

        private void deCrypt_Click(object sender, EventArgs e)
        {
            originText.Text = "";

            foreach (char c in secretText.Text)
            {
                char crypted = (char)(c - cryptoKey.Value);
                originText.Text += crypted.ToString();
            }
            MessageBox.Show("Вашето криптирано съобщение е: " + originText.Text);
            
        }

        private void Load_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                openFile.Text = openFileDialog1.FileName;
                secretText.Text = File.ReadAllText(openFile.Text);
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog1.FileName, secretText.Text);
            }
        }

        private void logIn_Click(object sender, EventArgs e)
        {
            
            if (name.Text == "UserName01" && pass.Text == "Password01")
            {
                name.BackColor = System.Drawing.SystemColors.Window;
                pass.BackColor = System.Drawing.SystemColors.Window;
                this.enCrypt.Enabled = true;
                this.deCrypt.Enabled = true;
                this.save.Enabled = true;
                this.load.Enabled = true;
                this.cryptoKey.Enabled = true;

            }
            else
            {
                name.BackColor = Color.Red;
                pass.BackColor = Color.Red;
                MessageBox.Show("Грешни Name или Pass \r\n " +
                    "за по сигурно ги пойскайте от създателя");
            }
        }

        private void instructions_Click(object sender, EventArgs e)
        {
            MessageBox.Show("За активиране на всички бутони, моля въведете правилни \r\n" +
                "User и Pass, тях може да получите единствено от създателя на  \r\n" +
                "програматас цел по голяма сигурност на вашите криптирани  \r\n" +
                "съобщения, не забравяйте да си споделяте какъв key сте използвали при криптирането\r\n" +
                "в случай че искате свой User и Pass, моля свържете се със създателя");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void instr_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Въведете нормалното съобщение в прозорец 1, от поле 'CryptoKey' \r\n" +
                "изберете произволен ключ, който задължително съгласувайте с получателя на  \r\n" +
                "съобщението, след това с бутон enCrypt замаскирайте вашто съобщение\r\n" +
                "появилия се текст в прозорец 2 можете да запазите като файл или да копирате и \r\n" +
                "изпратите на човека с който комуникирате тайно, не забравяйте да пойскате User и \r\n" +
                "Pass от създателя, в случай че искате ваши лични такива, той може да ви ги създате\r\n" +
                "При използване на бутон enCrypt Или deCrypt, ще видите прозорез със \r\n" +
                "вашето съответно криптирано или декриптирано съобщение, не забравяйте \r\n" +
                "да копирате необходимата информация тъй като след натискане на бутон 'ОК'\r\n" +
                "всички полета ще се изчистят с цел по-голяма сигурност");
        }

        private void clear_Click(object sender, EventArgs e)
        {
            originText.Clear();
            secretText.Clear();
        }
    }
}
