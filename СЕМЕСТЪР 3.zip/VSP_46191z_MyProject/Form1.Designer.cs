﻿namespace VSP_46191z_MyProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originText = new System.Windows.Forms.RichTextBox();
            this.deCrypt = new System.Windows.Forms.Button();
            this.enCrypt = new System.Windows.Forms.Button();
            this.cryptoKey = new System.Windows.Forms.NumericUpDown();
            this.cryptoKeyLabel = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.load = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.TextBox();
            this.pass = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.logIn = new System.Windows.Forms.Button();
            this.instructions = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFile = new System.Windows.Forms.Label();
            this.saveFile = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.instr = new System.Windows.Forms.Button();
            this.secretText = new System.Windows.Forms.RichTextBox();
            this.clear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cryptoKey)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // originText
            // 
            this.originText.Location = new System.Drawing.Point(12, 79);
            this.originText.Name = "originText";
            this.originText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.originText.Size = new System.Drawing.Size(527, 96);
            this.originText.TabIndex = 0;
            this.originText.Text = "";
            // 
            // deCrypt
            // 
            this.deCrypt.Location = new System.Drawing.Point(236, 350);
            this.deCrypt.Name = "deCrypt";
            this.deCrypt.Size = new System.Drawing.Size(75, 23);
            this.deCrypt.TabIndex = 2;
            this.deCrypt.Text = "deCrypt";
            this.deCrypt.UseVisualStyleBackColor = true;
            this.deCrypt.Click += new System.EventHandler(this.deCrypt_Click);
            // 
            // enCrypt
            // 
            this.enCrypt.Location = new System.Drawing.Point(236, 196);
            this.enCrypt.Name = "enCrypt";
            this.enCrypt.Size = new System.Drawing.Size(75, 23);
            this.enCrypt.TabIndex = 3;
            this.enCrypt.Text = "enCrypt";
            this.enCrypt.UseVisualStyleBackColor = true;
            this.enCrypt.Click += new System.EventHandler(this.enCrypt_Click);
            // 
            // cryptoKey
            // 
            this.cryptoKey.Location = new System.Drawing.Point(12, 44);
            this.cryptoKey.Name = "cryptoKey";
            this.cryptoKey.Size = new System.Drawing.Size(120, 20);
            this.cryptoKey.TabIndex = 4;
            // 
            // cryptoKeyLabel
            // 
            this.cryptoKeyLabel.AutoSize = true;
            this.cryptoKeyLabel.Location = new System.Drawing.Point(13, 25);
            this.cryptoKeyLabel.Name = "cryptoKeyLabel";
            this.cryptoKeyLabel.Size = new System.Drawing.Size(55, 13);
            this.cryptoKeyLabel.TabIndex = 5;
            this.cryptoKeyLabel.Text = "CryptoKey";
            // 
            // save
            // 
            this.save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.save.Location = new System.Drawing.Point(548, 25);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(96, 23);
            this.save.TabIndex = 6;
            this.save.Text = "Save Messages";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.Save_Click);
            // 
            // load
            // 
            this.load.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.load.Location = new System.Drawing.Point(548, 67);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(96, 23);
            this.load.TabIndex = 7;
            this.load.Text = "Load Messages";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.Load_Click);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(6, 40);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(100, 20);
            this.name.TabIndex = 9;
            // 
            // pass
            // 
            this.pass.Location = new System.Drawing.Point(115, 40);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(100, 20);
            this.pass.TabIndex = 9;
            this.pass.UseSystemPasswordChar = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.logIn);
            this.groupBox1.Controls.Add(this.instructions);
            this.groupBox1.Controls.Add(this.pass);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Location = new System.Drawing.Point(164, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(375, 69);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "sender";
            // 
            // logIn
            // 
            this.logIn.Location = new System.Drawing.Point(220, 38);
            this.logIn.Name = "logIn";
            this.logIn.Size = new System.Drawing.Size(75, 23);
            this.logIn.TabIndex = 12;
            this.logIn.Text = "Log IN";
            this.logIn.UseVisualStyleBackColor = true;
            this.logIn.Click += new System.EventHandler(this.logIn_Click);
            // 
            // instructions
            // 
            this.instructions.Location = new System.Drawing.Point(304, 38);
            this.instructions.Name = "instructions";
            this.instructions.Size = new System.Drawing.Size(56, 23);
            this.instructions.TabIndex = 12;
            this.instructions.Text = "Help";
            this.instructions.UseVisualStyleBackColor = true;
            this.instructions.Click += new System.EventHandler(this.instructions_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(116, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Pass";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Name";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFile
            // 
            this.openFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.openFile.AutoSize = true;
            this.openFile.Location = new System.Drawing.Point(545, 51);
            this.openFile.Name = "openFile";
            this.openFile.Size = new System.Drawing.Size(58, 13);
            this.openFile.TabIndex = 11;
            this.openFile.Text = "Open a file";
            // 
            // saveFile
            // 
            this.saveFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.saveFile.AutoSize = true;
            this.saveFile.Location = new System.Drawing.Point(545, 9);
            this.saveFile.Name = "saveFile";
            this.saveFile.Size = new System.Drawing.Size(57, 13);
            this.saveFile.TabIndex = 11;
            this.saveFile.Text = "Save a file";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(558, 350);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // instr
            // 
            this.instr.Location = new System.Drawing.Point(548, 196);
            this.instr.Name = "instr";
            this.instr.Size = new System.Drawing.Size(96, 23);
            this.instr.TabIndex = 14;
            this.instr.Text = "How to use";
            this.instr.UseVisualStyleBackColor = true;
            this.instr.Click += new System.EventHandler(this.instr_Click);
            // 
            // secretText
            // 
            this.secretText.Location = new System.Drawing.Point(12, 238);
            this.secretText.Name = "secretText";
            this.secretText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.secretText.Size = new System.Drawing.Size(527, 96);
            this.secretText.TabIndex = 1;
            this.secretText.Text = "";
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(558, 321);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 23);
            this.clear.TabIndex = 15;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 385);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.instr);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.saveFile);
            this.Controls.Add(this.openFile);
            this.Controls.Add(this.load);
            this.Controls.Add(this.save);
            this.Controls.Add(this.cryptoKeyLabel);
            this.Controls.Add(this.cryptoKey);
            this.Controls.Add(this.enCrypt);
            this.Controls.Add(this.deCrypt);
            this.Controls.Add(this.secretText);
            this.Controls.Add(this.originText);
            this.Controls.Add(this.groupBox1);
            this.MaximumSize = new System.Drawing.Size(677, 424);
            this.MinimumSize = new System.Drawing.Size(677, 424);
            this.Name = "Form1";
            this.Text = "Secret Messanger";
            ((System.ComponentModel.ISupportInitialize)(this.cryptoKey)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox originText;
        private System.Windows.Forms.Button deCrypt;
        private System.Windows.Forms.Button enCrypt;
        private System.Windows.Forms.NumericUpDown cryptoKey;
        private System.Windows.Forms.Label cryptoKeyLabel;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button load;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label openFile;
        private System.Windows.Forms.Button logIn;
        private System.Windows.Forms.Label saveFile;
        private System.Windows.Forms.Button instructions;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button instr;
        private System.Windows.Forms.RichTextBox secretText;
        private System.Windows.Forms.Button clear;
    }
}

